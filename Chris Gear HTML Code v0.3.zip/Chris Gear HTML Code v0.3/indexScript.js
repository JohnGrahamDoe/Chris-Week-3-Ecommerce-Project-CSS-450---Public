
document.addEventListener("DOMContentLoaded", function() {

    updateInventory();

    function updateInventory() {
        fetch('inventory.csv')
        .then(response => response.text())
        .then(csvData => {
        // Parse CSV data
        const products = csvData.split('\n').map(line => line.split(','));

        // Remove header row if exists
        const headerRow = products.shift();

        // Populate HTML with product data
        const productContainer = document.getElementById('product-container');

        products.forEach(product => {
            const [name, price, description, image, category, featured, id] = product;
            if (category.trim().toLowerCase() === "clothing") {
                const productItem = `
                    <div class="shop-item">
                        <span class="shop-item-title">${name}</span>
                        <img class="shop-item-image" src="${image}">
                        <div class="shop-item-details">
                            <span class="shop-item-price">$${price}</span>
                            <a href="products.html">Shop Now!</a>
                        </div>
                    </div>
                `;
                // modified from Web Dev Simplified
                productContainer.innerHTML += productItem;
            }
        });
        })
        .catch(error => {
        console.error('Error fetching or parsing CSV file:', error);
        });
    }

/*
Run chrome with tags:
    
    chrome.exe --user-data-dir="C://chrome-dev-disabled-security" --disable-web-security --disable-site-isolation-trials

to allow csv file to fetch properly
*/
/*
    Resources:

    Web Dev Simplified
    25 September 2018
    Introduction to Web Development
    Code version not specified
    Source code
    https://github.com/WebDevSimplified/Introduction-to-Web-Development/tree/master/Introduction%20to%20JavaScript/Lesson%201
*/
});